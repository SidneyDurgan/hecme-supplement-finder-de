import { useEffect, useRef, useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { Send, Square, Leaf, Zap, Moon, Shield, Brain, Dumbbell, Weight, Heart } from 'lucide-react'
import { Streamdown } from 'streamdown'

import { useAIChat } from '@/lib/ai-hook'
import type { ChatMessages } from '@/lib/ai-hook'

const GOALS = [
  { label: 'Build Muscle', icon: Dumbbell, prompt: 'I want to build muscle and improve my strength. What supplements should I consider?' },
  { label: 'Boost Energy', icon: Zap, prompt: 'I struggle with low energy and mental fatigue throughout the day. What supplements can help?' },
  { label: 'Better Sleep', icon: Moon, prompt: 'I have trouble sleeping and recovering. What supplements support deep sleep and recovery?' },
  { label: 'Lose Weight', icon: Weight, prompt: 'I want to support my weight loss efforts with supplements. What evidence-based options exist?' },
  { label: 'Brain & Focus', icon: Brain, prompt: 'I want to improve my focus, memory, and cognitive performance. What nootropics should I try?' },
  { label: 'Immunity', icon: Shield, prompt: 'I want to strengthen my immune system year-round. What supplements are worth taking?' },
  { label: 'Reduce Stress', icon: Heart, prompt: 'I deal with high stress and anxiety. What adaptogens and supplements can help?' },
  { label: 'Joint Health', icon: Leaf, prompt: 'I have joint discomfort and want to support long-term joint and connective tissue health.' },
]

function CapsuleIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" aria-hidden="true">
      <ellipse cx="11" cy="11" rx="7" ry="4.5" transform="rotate(-35 11 11)" stroke="currentColor" strokeWidth="1.5" />
      <line x1="5.5" y1="8.5" x2="16.5" y2="13.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  )
}

function TypingDots() {
  return (
    <div className="typing-indicator" aria-label="Advisor is thinking">
      <span /><span /><span />
    </div>
  )
}

function Messages({ messages, isLoading }: { messages: ChatMessages; isLoading: boolean }) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight
    }
  }, [messages, isLoading])

  return (
    <div ref={containerRef} className="messages-container">
      {messages.map((message) => (
        <div key={message.id} className={`message-row ${message.role === 'assistant' ? 'message-row--ai' : 'message-row--user'}`}>
          {message.role === 'assistant' && (
            <div className="message-avatar message-avatar--ai" aria-hidden="true">
              <CapsuleIcon />
            </div>
          )}
          <div className={`message-bubble ${message.role === 'assistant' ? 'message-bubble--ai' : 'message-bubble--user'}`}>
            {message.parts.map((part, i) =>
              part.type === 'text' && part.content ? (
                <div key={i} className="prose-content">
                  <Streamdown>{part.content}</Streamdown>
                </div>
              ) : null
            )}
          </div>
          {message.role === 'user' && (
            <div className="message-avatar message-avatar--user" aria-hidden="true">
              ME
            </div>
          )}
        </div>
      ))}
      {isLoading && (
        <div className="message-row message-row--ai">
          <div className="message-avatar message-avatar--ai" aria-hidden="true">
            <CapsuleIcon />
          </div>
          <div className="message-bubble message-bubble--ai">
            <TypingDots />
          </div>
        </div>
      )}
    </div>
  )
}

function EmptyState({ onSelect }: { onSelect: (prompt: string) => void }) {
  return (
    <div className="empty-state">
      <div className="empty-hero">
        <div className="brand-capsule" aria-hidden="true">
          <CapsuleIcon />
        </div>
        <h1 className="hero-headline">
          Find Your <em>Perfect</em><br />Supplement Stack
        </h1>
        <p className="hero-sub">
          Ask anything about supplements, or choose a goal below to get personalized, evidence-based recommendations.
        </p>
      </div>
      <div className="goals-grid">
        {GOALS.map((goal) => {
          const Icon = goal.icon
          return (
            <button
              key={goal.label}
              className="goal-chip"
              onClick={() => onSelect(goal.prompt)}
            >
              <Icon size={15} strokeWidth={1.8} />
              <span>{goal.label}</span>
            </button>
          )
        })}
      </div>
      <p className="disclaimer">
        For informational purposes only. Consult a healthcare provider before starting any new supplement regimen.
      </p>
    </div>
  )
}

function Home() {
  const [input, setInput] = useState('')
  const { messages, sendMessage, isLoading, stop } = useAIChat()
  const inputRef = useRef<HTMLInputElement>(null)

  function handleSend(text: string) {
    if (!text.trim() || isLoading) return
    sendMessage(text)
    setInput('')
    inputRef.current?.focus()
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="header-inner">
          <div className="brand">
            <div className="brand-icon" aria-hidden="true"><CapsuleIcon /></div>
            <div className="brand-text">
              <span className="brand-name">HEC<span className="brand-plus">+</span>ME</span>
              <span className="brand-tagline">Supplement Finder</span>
            </div>
          </div>
          <div className="header-badge">Powered by Claude</div>
        </div>
      </header>

      <main className="chat-main">
        {messages.length === 0 ? (
          <EmptyState onSelect={(p) => handleSend(p)} />
        ) : (
          <Messages messages={messages} isLoading={isLoading} />
        )}
      </main>

      <footer className="input-footer">
        <div className="input-inner">
          {isLoading && (
            <div className="stop-row">
              <button onClick={stop} className="stop-btn">
                <Square size={13} fill="currentColor" strokeWidth={0} />
                Stop generating
              </button>
            </div>
          )}
          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleSend(input)
            }}
            className="input-form"
          >
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about supplements, dosing, stacks, interactions…"
              className="chat-input"
              disabled={isLoading}
              autoFocus
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="send-btn"
              aria-label="Send message"
            >
              <Send size={16} strokeWidth={2} />
            </button>
          </form>
        </div>
      </footer>
    </div>
  )
}

export const Route = createFileRoute('/')({
  component: Home,
})
